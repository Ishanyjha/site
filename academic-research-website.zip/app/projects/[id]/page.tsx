import { notFound } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"

const projects = [
  {
    id: "ai-climate-modeling",
    title: "AI-Driven Climate Modeling",
    description: "Developing machine learning models to improve climate change predictions and mitigation strategies.",
    fullDescription:
      "This project focuses on leveraging artificial intelligence and machine learning techniques to enhance climate modeling accuracy. By incorporating vast amounts of historical climate data and real-time sensor information, we aim to create more precise and adaptable climate models. These advanced models will help policymakers and researchers better understand climate change patterns, predict future scenarios with higher accuracy, and develop more effective mitigation strategies.",
  },
  {
    id: "quantum-computing-algorithms",
    title: "Quantum Computing Algorithms",
    description:
      "Researching novel quantum algorithms for optimization problems in logistics and supply chain management.",
    fullDescription:
      "Our quantum computing research is centered on developing innovative algorithms to solve complex optimization problems in logistics and supply chain management. By harnessing the power of quantum superposition and entanglement, we aim to tackle NP-hard problems that are intractable for classical computers. This research has the potential to revolutionize industries by significantly improving efficiency in areas such as route optimization, resource allocation, and inventory management.",
  },
  {
    id: "ethical-ai-framework",
    title: "Ethical AI Framework",
    description: "Creating a comprehensive framework for ethical considerations in AI development and deployment.",
    fullDescription:
      "The Ethical AI Framework project is dedicated to addressing the growing concerns surrounding the ethical implications of artificial intelligence. We are developing a comprehensive set of guidelines, best practices, and evaluation metrics to ensure that AI systems are designed and deployed with strong ethical considerations. This framework covers areas such as fairness, transparency, privacy, and accountability, aiming to foster trust in AI technologies and promote their responsible use across various sectors.",
  },
]

export default function ProjectPage({ params }: { params: { id: string } }) {
  const project = projects.find((p) => p.id === params.id)

  if (!project) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">{project.title}</h1>
      <p className="text-gray-600 mb-8">{project.description}</p>
      <div className="bg-white p-6 rounded shadow mb-8">
        <h2 className="text-xl font-semibold mb-4">Project Details</h2>
        <p>{project.fullDescription}</p>
      </div>
      <Button asChild>
        <Link href="/#projects">Back to Projects</Link>
      </Button>
    </div>
  )
}

