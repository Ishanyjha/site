"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import Image from "next/image"

const publications = [
  {
    title: "Machine Learning Approaches to Climate Model Uncertainty Reduction",
    journal: "Journal of Climate Informatics",
    year: 2023,
    thumbnail: "/placeholder.svg?height=80&width=80",
  },
  {
    title: "Quantum-Inspired Algorithms for NP-Hard Problems in Supply Chain Optimization",
    journal: "Quantum Computing and Logistics",
    year: 2022,
    thumbnail: "/placeholder.svg?height=80&width=80",
  },
  {
    title: "Ethical Considerations in Automated Decision-Making Systems",
    journal: "AI Ethics Journal",
    year: 2021,
    thumbnail: "/placeholder.svg?height=80&width=80",
  },
]

const Publications = () => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null)

  return (
    <section id="publications" className="container mx-auto px-4">
      <h2 className="text-3xl font-bold mb-8 text-center">Recent Publications</h2>
      <ul className="space-y-4">
        {publications.map((pub, index) => (
          <motion.li
            key={index}
            className="bg-white p-4 rounded shadow flex items-center"
            onHoverStart={() => setHoveredIndex(index)}
            onHoverEnd={() => setHoveredIndex(null)}
          >
            <Image
              src={pub.thumbnail || "/placeholder.svg"}
              alt={`Thumbnail for ${pub.title}`}
              width={80}
              height={80}
              className="mr-4 rounded-lg"
            />
            <div className="flex-grow">
              <h3 className="font-semibold">{pub.title}</h3>
              <p className="text-gray-600">
                {pub.journal}, {pub.year}
              </p>
            </div>
            {hoveredIndex === index && (
              <motion.div
                className="w-2 h-full bg-blue-500 absolute left-0 top-0"
                initial={{ scaleY: 0 }}
                animate={{ scaleY: 1 }}
                transition={{ duration: 0.2 }}
              />
            )}
          </motion.li>
        ))}
      </ul>
    </section>
  )
}

export default Publications

