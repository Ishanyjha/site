import { Button } from "@/components/ui/button"

const Hero = () => {
  return (
    <section className="container mx-auto px-4 text-center">
      <h1 className="text-4xl font-bold mb-4">Dr. Jane Doe</h1>
      <h2 className="text-2xl text-gray-600 mb-6">Computer Science Researcher</h2>
      <p className="max-w-2xl mx-auto text-gray-700 mb-8">
        Exploring the frontiers of artificial intelligence and machine learning to solve complex real-world problems.
      </p>
      <Button asChild>
        <a href="#contact">Get in Touch</a>
      </Button>
    </section>
  )
}

export default Hero

