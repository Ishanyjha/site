import Image from "next/image"
import Link from "next/link"

const presentations = [
  {
    title: "The Future of AI in Climate Science",
    event: "Global Climate Conference",
    date: "2023-05-15",
    youtubeId: "dQw4w9WgXcQ",
  },
  {
    title: "Quantum Computing: A New Era in Optimization",
    event: "International Quantum Symposium",
    date: "2022-11-03",
    youtubeId: "dQw4w9WgXcQ",
  },
  {
    title: "Ethics in AI: Challenges and Solutions",
    event: "AI Ethics Forum",
    date: "2022-09-22",
    youtubeId: "dQw4w9WgXcQ",
  },
]

const Presentations = () => {
  return (
    <section id="presentations" className="container mx-auto px-4">
      <h2 className="text-3xl font-bold mb-8 text-center">Presentations</h2>
      <ul className="space-y-4">
        {presentations.map((presentation, index) => (
          <li key={index} className="bg-white p-4 rounded shadow flex items-center">
            <Link
              href={`https://www.youtube.com/watch?v=${presentation.youtubeId}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Image
                src={`https://img.youtube.com/vi/${presentation.youtubeId}/0.jpg`}
                alt={`Thumbnail for ${presentation.title}`}
                width={120}
                height={90}
                className="mr-4 rounded-lg transition-transform hover:scale-105"
              />
            </Link>
            <div>
              <h3 className="font-semibold">{presentation.title}</h3>
              <p className="text-gray-600">{presentation.event}</p>
              <p className="text-gray-500">{new Date(presentation.date).toLocaleDateString()}</p>
            </div>
          </li>
        ))}
      </ul>
    </section>
  )
}

export default Presentations

