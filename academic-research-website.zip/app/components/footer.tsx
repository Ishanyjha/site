const Footer = () => {
  return (
    <footer className="bg-gray-100 text-gray-600 py-8">
      <div className="container mx-auto px-4 text-center">
        <p>&copy; {new Date().getFullYear()} Dr. Jane Doe. All rights reserved.</p>
        <p className="mt-2">Department of Computer Science, University of Example</p>
      </div>
    </footer>
  )
}

export default Footer

