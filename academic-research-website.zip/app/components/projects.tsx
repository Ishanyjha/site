import Link from "next/link"
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"

const projects = [
  {
    id: "ai-climate-modeling",
    title: "AI-Driven Climate Modeling",
    description: "Developing machine learning models to improve climate change predictions and mitigation strategies.",
  },
  {
    id: "quantum-computing-algorithms",
    title: "Quantum Computing Algorithms",
    description:
      "Researching novel quantum algorithms for optimization problems in logistics and supply chain management.",
  },
  {
    id: "ethical-ai-framework",
    title: "Ethical AI Framework",
    description: "Creating a comprehensive framework for ethical considerations in AI development and deployment.",
  },
]

const Projects = () => {
  return (
    <section id="projects" className="container mx-auto px-4">
      <h2 className="text-3xl font-bold mb-8 text-center">Research Projects</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {projects.map((project) => (
          <Link href={`/projects/${project.id}`} key={project.id}>
            <Card className="h-full transition-transform hover:scale-105">
              <CardHeader>
                <CardTitle>{project.title}</CardTitle>
                <CardDescription>{project.description}</CardDescription>
              </CardHeader>
            </Card>
          </Link>
        ))}
      </div>
    </section>
  )
}

export default Projects

